#!/usr/bin/env python3
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import subprocess, os, threading, hashlib, shutil, datetime, re, sys
from pathlib import Path
from tkinter import ttk

# ------------------------- Sync Tool Section -------------------------
class SyncFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        # Initialize cancellation control
        self.current_sync_process = None
        self.cancel_flag = False
        
        # Create a labeled frame for Sync Option 1
        sync1_frame = tk.LabelFrame(self, text="Sync Option 1", padx=10, pady=10)
        sync1_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(sync1_frame, text="Source Directory:").grid(row=0, column=0, sticky="e", padx=5, pady=5)
        self.sync1_source_entry = tk.Entry(sync1_frame, width=50)
        self.sync1_source_entry.grid(row=0, column=1, padx=5, pady=5)
        tk.Button(sync1_frame, text="Select Source", command=lambda: self.select_directory(self.sync1_source_entry))\
            .grid(row=0, column=2, padx=5, pady=5)

        self.sync1_dest_entries = []
        for i in range(4):
            tk.Label(sync1_frame, text=f"Destination Directory {i+1}:").grid(row=i+1, column=0, sticky="e", padx=5, pady=5)
            entry = tk.Entry(sync1_frame, width=50)
            entry.grid(row=i+1, column=1, padx=5, pady=5)
            self.sync1_dest_entries.append(entry)
            tk.Button(sync1_frame, text="Select Destination", command=lambda e=entry: self.select_directory(e))\
                .grid(row=i+1, column=2, padx=5, pady=5)

        # Sync and Cancel buttons for Option 1
        tk.Button(sync1_frame, text="Sync", command=self.run_sync1).grid(row=5, column=1, pady=10)
        tk.Button(sync1_frame, text="Cancel Sync", command=self.cancel_sync).grid(row=5, column=2, pady=10)

        # Create a labeled frame for Sync Option 2
        sync2_frame = tk.LabelFrame(self, text="Sync Option 2", padx=10, pady=10)
        sync2_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(sync2_frame, text="Source Directory:").grid(row=0, column=0, sticky="e", padx=5, pady=5)
        self.sync2_source_entry = tk.Entry(sync2_frame, width=50)
        self.sync2_source_entry.grid(row=0, column=1, padx=5, pady=5)
        tk.Button(sync2_frame, text="Select Source", command=lambda: self.select_directory(self.sync2_source_entry))\
            .grid(row=0, column=2, padx=5, pady=5)

        self.sync2_dest_entries = []
        for i in range(4):
            tk.Label(sync2_frame, text=f"Destination Directory {i+1}:").grid(row=i+1, column=0, sticky="e", padx=5, pady=5)
            entry = tk.Entry(sync2_frame, width=50)
            entry.grid(row=i+1, column=1, padx=5, pady=5)
            self.sync2_dest_entries.append(entry)
            tk.Button(sync2_frame, text="Select Destination", command=lambda e=entry: self.select_directory(e))\
                .grid(row=i+1, column=2, padx=5, pady=5)

        # Sync and Cancel buttons for Option 2
        tk.Button(sync2_frame, text="Sync", command=self.run_sync2).grid(row=5, column=1, pady=10)
        tk.Button(sync2_frame, text="Cancel Sync", command=self.cancel_sync).grid(row=5, column=2, pady=10)
        
        # Add Clear Directories Button for Sync tab
        tk.Button(self, text="Clear Directories", command=self.clear_directories).pack(pady=5)

        # Create a frame for the two logging checkboxes
        checkbox_frame = tk.Frame(self)
        checkbox_frame.pack(padx=10, pady=5, anchor="w")
        self.global_logging_enabled = tk.BooleanVar(value=True)
        self.logging_dest_enabled = tk.BooleanVar(value=False)
        tk.Checkbutton(checkbox_frame, text="Enable Logging", variable=self.global_logging_enabled)\
            .pack(side="left", padx=5)
        tk.Checkbutton(checkbox_frame, text="Enable Logging Destination", variable=self.logging_dest_enabled)\
            .pack(side="left", padx=5)

        # Global output window to display Sync logs
        self.output_window = tk.Text(self, height=15, width=100)
        self.output_window.pack(padx=10, pady=10)

    def select_directory(self, entry):
        directory = filedialog.askdirectory(title="Select Directory")
        if directory:
            entry.delete(0, tk.END)
            entry.insert(0, directory)

    def run_sync(self, source, dest_list):
        if not source:
            messagebox.showerror("Error", "Source directory must be selected.")
            return

        self.cancel_flag = False  # Reset cancellation flag
        global_log_file = None
        global_log_filename = None
        if self.global_logging_enabled.get():
            try:
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                global_log_filename = f"rsync_log_{timestamp}.txt"
                global_log_file = open(global_log_filename, "w")
                global_log_file.write(f"--- Global Sync Started for source: {source} ---\n")
            except Exception as e:
                messagebox.showerror("Global Logging Error", f"Failed to open global log file: {e}")
                global_log_file = None
                global_log_filename = None

        for dest in dest_list:
            if self.cancel_flag:
                self.output_window.insert(tk.END, "Sync cancelled by user.\n")
                break
            if not dest.strip():
                continue

            self.output_window.insert(tk.END, f"\nStarting sync: {source} -> {dest}\n")

            dest_log_file = None
            if self.logging_dest_enabled.get():
                log_path = os.path.join(dest, "rsync_log.txt")
                try:
                    dest_log_file = open(log_path, "a")
                    dest_log_file.write(f"--- Sync started: {source} -> {dest} ---\n")
                except Exception as e:
                    messagebox.showerror("Destination Logging Error", f"Failed to open log file at {log_path}: {e}")
                    dest_log_file = None

            command = ["rsync", "-av", "--progress", source, dest]
            try:
                self.current_sync_process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                while True:
                    if self.cancel_flag:
                        self.current_sync_process.terminate()
                        self.output_window.insert(tk.END, "Cancelling current sync...\n")
                        break
                    line = self.current_sync_process.stdout.readline()
                    if not line and self.current_sync_process.poll() is not None:
                        break
                    if line:
                        self.output_window.insert(tk.END, line)
                        self.output_window.see(tk.END)
                        self.output_window.update()
                        if global_log_file:
                            global_log_file.write(line)
                            global_log_file.flush()
                        if dest_log_file:
                            dest_log_file.write(line)
                            dest_log_file.flush()
                if dest_log_file:
                    dest_log_file.write(f"--- Sync finished for {dest} ---\n\n")
                    dest_log_file.close()
                if global_log_file:
                    global_log_file.write(f"--- Sync finished for {dest} ---\n")
                    global_log_file.flush()
                if self.cancel_flag:
                    break
            except Exception as e:
                messagebox.showerror("Execution Error", f"Failed to run sync on {dest}: {e}")
        if global_log_file:
            global_log_file.write(f"--- Global Sync Finished for source: {source} ---\n\n")
            global_log_file.close()
        # If cancellation occurred, clear the partial global log file
        if self.cancel_flag and global_log_filename is not None:
            try:
                os.remove(global_log_filename)
                self.output_window.insert(tk.END, "Partial global log cleared.\n")
            except Exception as e:
                self.output_window.insert(tk.END, f"Error clearing partial global log: {e}\n")
        self.current_sync_process = None

    def run_sync1(self):
        source = self.sync1_source_entry.get().strip()
        dest_list = [entry.get().strip() for entry in self.sync1_dest_entries]
        threading.Thread(target=self.run_sync, args=(source, dest_list), daemon=True).start()

    def run_sync2(self):
        source = self.sync2_source_entry.get().strip()
        dest_list = [entry.get().strip() for entry in self.sync2_dest_entries]
        threading.Thread(target=self.run_sync, args=(source, dest_list), daemon=True).start()

    def cancel_sync(self):
        self.cancel_flag = True
        if self.current_sync_process is not None:
            try:
                self.current_sync_process.terminate()
            except Exception as e:
                messagebox.showerror("Cancel Error", f"Error cancelling sync: {e}")

    def clear_directories(self):
        self.sync1_source_entry.delete(0, tk.END)
        for entry in self.sync1_dest_entries:
            entry.delete(0, tk.END)
        self.sync2_source_entry.delete(0, tk.END)
        for entry in self.sync2_dest_entries:
            entry.delete(0, tk.END)
        self.output_window.delete(1.0, tk.END)

# ------------------------- File Comparator Section -------------------------
def compute_hash(file_path):
    hash_obj = hashlib.sha256()
    try:
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_obj.update(chunk)
    except Exception:
        return None
    return hash_obj.hexdigest()

def scan_drive_attributes(root_path, compare_size, compare_date, compare_hash, skip_hidden=False):
    files_dict = {}
    for dirpath, dirnames, filenames in os.walk(root_path):
        dirnames[:] = [d for d in dirnames if d != '_gsdata_']
        if skip_hidden:
            dirnames[:] = [d for d in dirnames if not d.startswith('.')]
        rel_dir = os.path.relpath(dirpath, root_path)
        if rel_dir != ".":
            key = rel_dir + os.sep
            files_dict[key] = {"type": "directory"}
        for filename in filenames:
            if filename == ".DS_Store":
                continue
            full_path = os.path.join(dirpath, filename)
            rel_path = os.path.relpath(full_path, root_path)
            attr = {"type": "file"}
            if compare_size:
                try:
                    attr['size'] = os.path.getsize(full_path)
                except Exception:
                    attr['size'] = None
            if compare_date:
                try:
                    attr['mod_date'] = os.path.getmtime(full_path)
                except Exception:
                    attr['mod_date'] = None
            if compare_hash:
                attr['hash'] = compute_hash(full_path)
            files_dict[rel_path] = attr
    return files_dict

class FileComparatorFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.drive_paths = []
        self.reference_drive = None
        self.create_widgets()

    def create_widgets(self):
        top_frame = tk.Frame(self)
        top_frame.pack(pady=5)
        self.add_button = tk.Button(top_frame, text="Add Drive", command=self.add_drive)
        self.add_button.grid(row=0, column=0, padx=5)
        self.clear_button = tk.Button(top_frame, text="Clear Drives", command=self.clear_drives)
        self.clear_button.grid(row=0, column=1, padx=5)
        self.set_ref_button = tk.Button(top_frame, text="Set as Reference", command=self.set_reference)
        self.set_ref_button.grid(row=0, column=2, padx=5)
        self.auto_ref_button = tk.Button(top_frame, text="Auto Reference", command=self.auto_reference)
        self.auto_ref_button.grid(row=0, column=3, padx=5)
        self.listbox = tk.Listbox(self, selectmode=tk.SINGLE, width=80)
        self.listbox.pack(pady=5)
        self.ref_label = tk.Label(self, text="Reference Drive: Not Set")
        self.ref_label.pack(pady=5)
        options_frame = tk.LabelFrame(self, text="Comparison Options")
        options_frame.pack(pady=5, fill="x", padx=10)
        self.compare_size_var = tk.BooleanVar(value=True)
        self.compare_date_var = tk.BooleanVar(value=False)
        self.compare_hash_var = tk.BooleanVar(value=False)
        self.skip_hidden_var = tk.BooleanVar(value=True)
        self.cb_size = tk.Checkbutton(options_frame, text="Compare Size", variable=self.compare_size_var)
        self.cb_size.grid(row=0, column=0, padx=5, pady=2, sticky="w")
        self.cb_date = tk.Checkbutton(options_frame, text="Compare Modification Date", variable=self.compare_date_var)
        self.cb_date.grid(row=0, column=1, padx=5, pady=2, sticky="w")
        self.cb_hash = tk.Checkbutton(options_frame, text="Compare File Hash", variable=self.compare_hash_var)
        self.cb_hash.grid(row=0, column=2, padx=5, pady=2, sticky="w")
        self.cb_hidden = tk.Checkbutton(options_frame, text="Skip Hidden Directories", variable=self.skip_hidden_var)
        self.cb_hidden.grid(row=1, column=0, padx=5, pady=2, sticky="w")
        # New logging checkboxes for File Comparator:
        self.fc_global_logging_enabled = tk.BooleanVar(value=False)
        self.fc_dest_logging_enabled = tk.BooleanVar(value=False)
        tk.Checkbutton(options_frame, text="Enable Logging", variable=self.fc_global_logging_enabled)\
            .grid(row=2, column=0, padx=5, pady=2, sticky="w")
        tk.Checkbutton(options_frame, text="Enable Logging Destination", variable=self.fc_dest_logging_enabled)\
            .grid(row=2, column=1, padx=5, pady=2, sticky="w")
        
        self.progress_bar = ttk.Progressbar(self, orient="horizontal", length=500, mode="determinate")
        self.progress_bar.pack(pady=10)
        self.status_label = tk.Label(self, text="Status: Idle")
        self.status_label.pack(pady=5)
        self.compare_button = tk.Button(self, text="Compare Files", command=self.compare_files)
        self.compare_button.pack(pady=5)
        self.text_area = scrolledtext.ScrolledText(self, width=80, height=15)
        self.text_area.pack(pady=5)

    def add_drive(self):
        drive = filedialog.askdirectory(title="Select External Drive Directory")
        if drive:
            self.drive_paths.append(drive)
            self.listbox.insert(tk.END, drive)

    def clear_drives(self):
        self.drive_paths = []
        self.reference_drive = None
        self.listbox.delete(0, tk.END)
        self.ref_label.config(text="Reference Drive: Not Set")
        self.text_area.delete('1.0', tk.END)
        self.progress_bar['value'] = 0

    def set_reference(self):
        selection = self.listbox.curselection()
        if selection:
            index = selection[0]
            self.reference_drive = self.drive_paths[index]
            self.ref_label.config(text=f"Reference Drive: {self.reference_drive}")
        else:
            messagebox.showwarning("Selection Error", "Please select a drive from the list to set as reference.")

    def auto_reference(self):
        self.clear_drives()
        volumes_root = "/Volumes"
        if not os.path.exists(volumes_root):
            messagebox.showerror("Error", "Volumes directory not found.")
            return
        volumes = [d for d in os.listdir(volumes_root) if os.path.isdir(os.path.join(volumes_root, d))]
        filtered_volumes = []
        for vol in volumes:
            if len(vol) >= 3 and vol[-3] == '_' and vol[-2:].isdigit():
                filtered_volumes.append(vol)
        if not filtered_volumes:
            messagebox.showinfo("Auto Reference", "No external volumes with expected naming found.")
            return
        for vol in filtered_volumes:
            full_path = os.path.join(volumes_root, vol)
            self.drive_paths.append(full_path)
            self.listbox.insert(tk.END, full_path)
        reference_drive = None
        for vol in filtered_volumes:
            if vol.endswith("_01"):
                reference_drive = os.path.join(volumes_root, vol)
                break
        if reference_drive:
            self.reference_drive = reference_drive
            self.ref_label.config(text=f"Reference Drive: {reference_drive}")
        else:
            messagebox.showinfo("Auto Reference", "No volume ending with '_01' found to set as reference.")

    def compare_files(self):
        if len(self.drive_paths) < 1:
            messagebox.showwarning("No Drives", "Please add at least one drive.")
            return
        self.text_area.delete('1.0', tk.END)
        self.progress_bar['value'] = 0
        self.status_label.config(text="Status: Starting comparison...")
        thread = threading.Thread(target=self.perform_comparison)
        thread.start()

    def perform_comparison(self):
        compare_size = self.compare_size_var.get()
        compare_date = self.compare_date_var.get()
        compare_hash = self.compare_hash_var.get()
        skip_hidden = self.skip_hidden_var.get()
        self.update_status("Scanning all drives...")
        drive_files = {}
        for drive in self.drive_paths:
            self.update_status(f"Scanning drive: {drive}")
            drive_files[drive] = scan_drive_attributes(
                drive, compare_size, compare_date, compare_hash, skip_hidden=skip_hidden
            )
        all_keys = set()
        for files_dict in drive_files.values():
            all_keys.update(files_dict.keys())
        total_keys = len(all_keys)
        if total_keys == 0:
            self.append_text("No files or directories found on any drive.\n")
            self.update_status("Scan complete. No items found.")
            return
        self.update_status("Comparing items across all drives...")
        discrepancies = {}
        processed = 0
        ref_drive = self.reference_drive if self.reference_drive in drive_files else None
        for key in all_keys:
            processed += 1
            self.update_progress(processed, total_keys)
            ref_attr = drive_files[ref_drive].get(key) if ref_drive else None
            for drive, files_dict in drive_files.items():
                if key not in files_dict:
                    discrepancies.setdefault(drive, []).append(f"Missing item: {key}")
                else:
                    comp_attr = files_dict[key]
                    if ref_attr:
                        if ref_attr.get("type") != comp_attr.get("type"):
                            discrepancies.setdefault(drive, []).append(
                                f"Type mismatch for {key} (Ref: {ref_attr.get('type')}, {drive}: {comp_attr.get('type')})"
                            )
                        elif ref_attr.get("type") == "file":
                            messages = []
                            if compare_size and ref_attr.get('size') != comp_attr.get('size'):
                                messages.append(
                                    f"Size mismatch for {key} (Ref: {ref_attr.get('size')}, {drive}: {comp_attr.get('size')})"
                                )
                            if compare_date and ref_attr.get('mod_date') != comp_attr.get('mod_date'):
                                messages.append(f"Modification date mismatch for {key}")
                            if compare_hash and ref_attr.get('hash') != comp_attr.get('hash'):
                                messages.append(f"Hash mismatch for {key}")
                            if messages:
                                discrepancies.setdefault(drive, []).extend(messages)
        if not discrepancies:
            self.append_text("All drives have the same items and attributes.\n")
            self.update_status("Comparison complete. No discrepancies found.")
            messagebox.showinfo("Comparison Result", "All drives match across all items.")
        else:
            result_text = ""
            for drive, messages in discrepancies.items():
                result_text += f"Discrepancies for drive: {drive}\n"
                for msg in messages:
                    result_text += "  " + msg + "\n"
                result_text += "\n"
            self.append_text(result_text)
            log_files = {}
            if self.fc_global_logging_enabled.get():
                log_files["global"] = self.write_global_log(discrepancies)
            if self.fc_dest_logging_enabled.get():
                log_files["destination"] = self.write_dest_logs(discrepancies)
            self.update_status("Comparison complete with discrepancies.")
            messagebox.showwarning("Differences Found", f"Discrepancies found. Logs: {log_files}")

    def write_global_log(self, discrepancies):
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        log_filename = f"file_comparison_log_{timestamp}.txt"
        with open(log_filename, "w") as log_file:
            for drive, messages in discrepancies.items():
                log_file.write(f"Discrepancies for drive: {drive}\n")
                for msg in messages:
                    log_file.write("  " + msg + "\n")
                log_file.write("\n")
        return log_filename

    def write_dest_logs(self, discrepancies):
        dest_log_files = {}
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        for drive, messages in discrepancies.items():
            if messages:
                dest_log_path = os.path.join(drive, f"file_comparison_log_{timestamp}.txt")
                with open(dest_log_path, "w") as log_file:
                    log_file.write(f"Discrepancies for drive: {drive}\n")
                    for msg in messages:
                        log_file.write("  " + msg + "\n")
                    log_file.write("\n")
                dest_log_files[drive] = dest_log_path
        return dest_log_files

    def update_status(self, message):
        self.status_label.after(0, lambda: self.status_label.config(text=f"Status: {message}"))

    def append_text(self, text):
        self.text_area.after(0, lambda: self.text_area.insert(tk.END, text))

    def update_progress(self, value, maximum):
        self.progress_bar.after(0, lambda: self.progress_bar.config(value=value, maximum=maximum))

# ------------------------- Render Check Section -------------------------
class RenderCheckFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.init_paths()
        self.create_ui()

    def init_paths(self):
        """Initialize paths and variables."""
        self.camera_dir = None
        self.transcode_dirs = [None] * 4
        self.logging_enabled = tk.BooleanVar(value=False)
        self.logging_dir = None

        # Create temp directory in Application Support (macOS) or home folder.
        if sys.platform == 'darwin':
            self.temp_dir = Path.home() / "Library" / "Application Support" / "RenderCheck"
        else:
            self.temp_dir = Path.home() / ".rendercheck"
        self.temp_dir.mkdir(parents=True, exist_ok=True)

    def create_ui(self):
        """Create the main user interface."""
        # Use the frame (instead of a new root window) so that this tab matches the style of the others.
        self.main_frame = tk.Frame(self, padx=20, pady=20)
        self.main_frame.pack(expand=True, fill='both')
        self.create_camera_section()
        self.create_transcode_section()
        self.create_logging_section()
        # "Run Comparison" button using default styling (without explicit width/height)
        tk.Button(self.main_frame, text="Run Comparison", command=self.run_comparison).pack(pady=20)
        self.create_output_area()

    def create_camera_section(self):
        """Create camera originals section."""
        frame = tk.Frame(self.main_frame)
        frame.pack(fill='x', pady=(0, 10))
        
        tk.Label(frame, text="Camera Originals:").pack(side='left')
        self.camera_label = tk.Label(frame, text="Not Selected", fg="red")
        self.camera_label.pack(side='left', padx=10)
        tk.Button(frame, text="Select", command=self.select_camera).pack(side='right')

    def create_transcode_section(self):
        """Create transcode directories section."""
        self.transcode_labels = []
        for i in range(4):
            frame = tk.Frame(self.main_frame)
            frame.pack(fill='x', pady=5)
            
            tk.Label(frame, text=f"Transcodes {i+1}:").pack(side='left')
            label = tk.Label(frame, text="Not Selected", fg="red")
            label.pack(side='left', padx=10)
            self.transcode_labels.append(label)
            tk.Button(frame, text="Select", command=lambda idx=i: self.select_transcode(idx)).pack(side='right')

    def create_logging_section(self):
        """Create logging section."""
        frame = tk.Frame(self.main_frame)
        frame.pack(fill='x', pady=10)
        
        tk.Checkbutton(frame, text="Enable Logging", variable=self.logging_enabled, command=self.toggle_logging)\
            .pack(side='left')
        
        self.log_dir_label = tk.Label(frame, text="Log Dir: Not Selected", fg="red")
        self.log_dir_label.pack(side='left', padx=10)
        
        self.log_dir_button = tk.Button(frame, text="Select", command=self.select_log_dir, state=tk.DISABLED)
        self.log_dir_button.pack(side='right')

    def create_output_area(self):
        """Create output text area."""
        self.output_text = tk.Text(self.main_frame, height=15, width=60)
        self.output_text.pack(fill='both', expand=True)

    def select_camera(self):
        """Select camera originals directory."""
        folder = filedialog.askdirectory(title="Select Camera Originals Directory")
        if folder:
            self.camera_dir = folder
            self.camera_label.config(text=os.path.basename(folder), fg="green")

    def select_transcode(self, idx):
        """Select transcode directory."""
        folder = filedialog.askdirectory(title=f"Select Transcodes Directory {idx + 1}")
        if folder:
            self.transcode_dirs[idx] = folder
            self.transcode_labels[idx].config(text=os.path.basename(folder), fg="green")

    def toggle_logging(self):
        """Toggle logging functionality."""
        if self.logging_enabled.get():
            self.log_dir_button.config(state=tk.NORMAL)
        else:
            self.log_dir_button.config(state=tk.DISABLED)
            self.logging_dir = None
            self.log_dir_label.config(text="Log Dir: Not Selected", fg="red")

    def select_log_dir(self):
        """Select logging directory."""
        folder = filedialog.askdirectory(title="Select Logging Directory")
        if folder:
            self.logging_dir = folder
            self.log_dir_label.config(text=f"Log Dir: {os.path.basename(folder)}", fg="green")

    def ignore_file(self, p: Path):
        """
        Return True if the file should be ignored.
        Ignores files starting with '._' and those with extensions in the ignore list,
        and also ignores '.DS_Store' files.
        """
        ignore_extensions = {
            '.log', '.bin', '.inp', '.xml', '.ind', '.gsl', '.mhl',
            '.ale', '.jpg', '.bnp', '._gs', '.int'
        }
        return p.name.startswith("._") or p.suffix.lower() in ignore_extensions or p.name.lower() == ".ds_store"

    def normalize_name(self, filename: str):
        """
        Normalize the filename for comparison by returning the stem (base name without extension)
        in lowercase.
        """
        return Path(filename).stem.lower()

    def process_master_files(self, folder):
        """
        Recursively process the master files directory.
        Returns a dictionary mapping normalized names to a list of full file names.
        """
        self.output_text.insert(tk.END, f"Processing master files in: {folder}\n")
        master_dict = {}
        for p in Path(folder).rglob('*'):
            if p.is_file() and not self.ignore_file(p):
                norm = self.normalize_name(p.name)
                master_dict.setdefault(norm, []).append(p.name)
        return master_dict

    def process_transcode_files(self, folder):
        """
        Recursively process the transcode files directory.
        Returns a dictionary mapping normalized names to a list of full file names.
        """
        self.output_text.insert(tk.END, f"Processing transcodes in: {folder}\n")
        trans_dict = {}
        for p in Path(folder).rglob('*'):
            if p.is_file() and not self.ignore_file(p):
                norm = self.normalize_name(p.name)
                trans_dict.setdefault(norm, []).append(p.name)
        return trans_dict

    def compare_dicts(self, master_dict, trans_dict):
        """
        Compare master and transcode dictionaries based on normalized names.
        Returns a list of strings indicating which files (by full name) are missing in one set.
        """
        master_set = set(master_dict.keys())
        trans_set = set(trans_dict.keys())
        diff_norm = master_set.symmetric_difference(trans_set)
        differences = []
        for norm in diff_norm:
            if norm in master_dict and norm not in trans_set:
                for fname in master_dict[norm]:
                    differences.append(f"(Master only) {fname}")
            if norm in trans_dict and norm not in master_set:
                for fname in trans_dict[norm]:
                    differences.append(f"(Transcode only) {fname}")
        return differences

    def run_comparison(self):
        """Run the comparison process."""
        if not self.camera_dir:
            messagebox.showwarning("Warning", "Please select Camera Originals directory first")
            return
        
        self.output_text.delete(1.0, tk.END)
        
        try:
            master_dict = self.process_master_files(self.camera_dir)
            
            combined_trans_dict = {}
            for dir_path in self.transcode_dirs:
                if dir_path:
                    trans_dict = self.process_transcode_files(dir_path)
                    for norm, names in trans_dict.items():
                        combined_trans_dict.setdefault(norm, []).extend(names)
            
            differences = self.compare_dicts(master_dict, combined_trans_dict)
            differences_sorted = sorted(differences, key=lambda x: x.lower())
            
            if not differences_sorted:
                messagebox.showinfo("Success", "All files match!")
                self.output_text.insert(tk.END, "Comparison complete - No differences found\n")
            else:
                self.output_text.insert(tk.END, "Differences found:\n\n")
                for diff in differences_sorted:
                    self.output_text.insert(tk.END, f"- {diff}\n")
                messagebox.showwarning("Differences Found", 
                    f"Found {len(differences_sorted)} differences. Check output for details.")
            
            # Logging: if enabled, write the sorted output to a log file.
            if self.logging_enabled.get() and self.logging_dir:
                log_filename = datetime.datetime.now().strftime("rendercheck_log_%Y%m%d_%H%M%S.txt")
                log_path = Path(self.logging_dir) / log_filename
                log_content = self.output_text.get("1.0", tk.END)
                with open(log_path, 'w', encoding='utf-8') as log_file:
                    log_file.write(log_content)
                self.output_text.insert(tk.END, f"\nLog saved to: {log_path}\n")
            
        except Exception as e:
            messagebox.showerror("Error", f"Comparison failed: {str(e)}")
            self.output_text.insert(tk.END, f"Error during comparison: {str(e)}\n")

    def clear_directories(self):
        """Clear selected directories and output."""
        self.camera_dir = None
        self.camera_label.config(text="Not Selected", fg="red")
        for i in range(len(self.transcode_dirs)):
            self.transcode_dirs[i] = None
            self.transcode_labels[i].config(text="Not Selected", fg="red")
        self.output_text.delete(1.0, tk.END)

    def on_closing(self):
        """Clean up temporary files and close the application."""
        try:
            for file in self.temp_dir.glob("*.txt"):
                file.unlink(missing_ok=True)
            self.root.destroy()
        except Exception:
            sys.exit(0)

# ------------------------- Trash .drx Files Section -------------------------
class TrashDrxFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.selected_directory = ""
        self.create_widgets()
    
    def create_widgets(self):
        self.load_btn = tk.Button(self, text="Load Directory", command=self.load_directory)
        self.load_btn.pack(pady=10)
        self.dir_label = tk.Label(self, text="No directory selected")
        self.dir_label.pack(pady=5)
        self.trash_btn = tk.Button(self, text="Trash .drx", command=self.trash_drx)
        self.trash_btn.pack(pady=10)
        self.output_text = tk.Text(self, height=15, wrap=tk.WORD)
        self.output_text.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
    
    def load_directory(self):
        directory = filedialog.askdirectory(title="Select Directory")
        if directory:
            self.selected_directory = directory
            self.dir_label.config(text=f"Selected Directory: {directory}")
            self.log_output(f"Loaded directory: {directory}")
    
    def trash_drx(self):
        if not self.selected_directory:
            messagebox.showerror("Error", "No directory selected. Please load a directory first.")
            return
        self.log_output("Starting to trash .drx files...\n")
        move_drx_files(self.selected_directory, output_callback=self.log_output)
        self.log_output("\nOperation completed.")
    
    def log_output(self, message):
        self.output_text.insert(tk.END, message + "\n")
        self.output_text.see(tk.END)

def move_drx_files(target_directory, output_callback=None):
    trash_dir = os.path.expanduser("~/.Trash")
    if not os.path.isdir(trash_dir):
        if output_callback:
            output_callback(f"Trash directory not found: {trash_dir}")
        return
    files_moved = 0
    for root_dir, dirs, files in os.walk(target_directory):
        for file in files:
            if file.endswith(".drx"):
                src = os.path.join(root_dir, file)
                dest = os.path.join(trash_dir, file)
                base, ext = os.path.splitext(file)
                counter = 1
                while os.path.exists(dest):
                    dest = os.path.join(trash_dir, f"{base}_{counter}{ext}")
                    counter += 1
                if output_callback:
                    output_callback(f"Moving: {src} -> {dest}")
                shutil.move(src, dest)
                files_moved += 1
    if output_callback:
        output_callback(f"Total .drx files moved: {files_moved}")

# ------------------------- Main Application: DIT Tools -------------------------
def main():
    root = tk.Tk()
    root.title("DIT Tools")
    notebook = ttk.Notebook(root)
    notebook.pack(fill='both', expand=True)
    
    # Sync Tool Tab
    sync_frame = SyncFrame(notebook)
    notebook.add(sync_frame, text="Sync")
    
    # File Comparator Tool Tab
    comparator_frame = FileComparatorFrame(notebook)
    notebook.add(comparator_frame, text="File Comparator")
    
    # Render Check Tool Tab
    render_frame = RenderCheckFrame(notebook)
    notebook.add(render_frame, text="Render Check")
    
    # Trash .drx Files Tool Tab
    trash_frame = TrashDrxFrame(notebook)
    notebook.add(trash_frame, text="Trash .drx Files")
    
    root.mainloop()

if __name__ == "__main__":
    main()