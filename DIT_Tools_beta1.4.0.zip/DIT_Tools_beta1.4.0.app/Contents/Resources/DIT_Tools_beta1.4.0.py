#!/usr/bin/env python3
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import subprocess, os, threading, hashlib, shutil, datetime, re, sys
from tkinter import ttk
from datetime import datetime

# ------------------------- Style Constants -------------------------
class UIStyle:
    BUTTON_STYLE = {
        'width': 15,
        'padding': 5
    }
    LABEL_FONT = ('Helvetica', 10)
    HEADER_FONT = ('Helvetica', 12, 'bold')
    
    @staticmethod
    def configure_styles():
        style = ttk.Style()
        style.configure('DIT.TButton', padding=UIStyle.BUTTON_STYLE['padding'], width=UIStyle.BUTTON_STYLE['width'])
        style.configure('Header.TLabel', font=UIStyle.HEADER_FONT)
        style.configure('DIT.TLabel', font=UIStyle.LABEL_FONT)

# ------------------------- Project Section -------------------------
class ProjectFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        UIStyle.configure_styles()
        self.output_directory = ""
        
        # Create StringVars for fields
        self.job_var = tk.StringVar()
        self.client_var = tk.StringVar()
        self.project_var = tk.StringVar()
        self.preview_var = tk.StringVar(value="Preview will appear here")
        
        # Build UI using grid with labels next to entries
        ttk.Label(self, text="Job Number:", style="DIT.TLabel").grid(row=0, column=0, sticky="e", padx=5, pady=5)
        self.job_entry = ttk.Entry(self, textvariable=self.job_var)
        self.job_entry.grid(row=0, column=1, padx=10, pady=5)
        self.job_entry.bind("<KeyRelease>", self.update_preview)
        
        ttk.Label(self, text="Job Name/Client:", style="DIT.TLabel").grid(row=1, column=0, sticky="e", padx=5, pady=5)
        self.client_entry = ttk.Entry(self, textvariable=self.client_var)
        self.client_entry.grid(row=1, column=1, padx=10, pady=5)
        self.client_entry.bind("<KeyRelease>", self.update_preview)
        
        ttk.Label(self, text="Production Co.:", style="DIT.TLabel").grid(row=2, column=0, sticky="e", padx=5, pady=5)
        self.project_entry = ttk.Entry(self, textvariable=self.project_var)
        self.project_entry.grid(row=2, column=1, padx=10, pady=5)
        self.project_entry.bind("<KeyRelease>", self.update_preview)
        
        ttk.Label(self, text="Preview:", style="DIT.TLabel").grid(row=3, column=0, sticky="e", padx=5, pady=5)
        self.preview_label = ttk.Label(self, textvariable=self.preview_var, style="DIT.TLabel")
        self.preview_label.grid(row=3, column=1, padx=10, pady=5)
        
        # Button to select output directory
        self.select_dir_button = ttk.Button(self, text="Select Output Directory", style="DIT.TButton", command=self.select_directory)
        self.select_dir_button.grid(row=4, column=0, columnspan=2, pady=10)
        
        self.directory_label = ttk.Label(self, text="No directory selected", style="DIT.TLabel")
        self.directory_label.grid(row=5, column=0, columnspan=2, pady=5)
        
        # Transcode Options
        transcode_frame = ttk.LabelFrame(self, text="Transcode Options", padding=10)
        transcode_frame.grid(row=6, column=0, columnspan=2, padx=10, pady=10, sticky="ew")
        
        self.var_dnxdh = tk.BooleanVar(value=True)
        self.var_dnxhr = tk.BooleanVar(value=False)
        self.var_prores_proxy = tk.BooleanVar(value=False)
        self.var_prores_lt = tk.BooleanVar(value=False)
        ttk.Checkbutton(transcode_frame, text="AVID_DNxHD_36_MXF_1080P_OFFLINE", variable=self.var_dnxdh).grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(transcode_frame, text="AVID_DNxHR_LB_MXF_1080P_OFFLINE", variable=self.var_dnxhr).grid(row=1, column=0, sticky="w")
        ttk.Checkbutton(transcode_frame, text="PRORES_422_PROXY_1080P_OFFLINE", variable=self.var_prores_proxy).grid(row=2, column=0, sticky="w")
        ttk.Checkbutton(transcode_frame, text="PRORES_422_LT_1080P_OFFLINE", variable=self.var_prores_lt).grid(row=3, column=0, sticky="w")
        
        # Custom transcode option
        self.var_custom = tk.BooleanVar(value=False)
        custom_check = ttk.Checkbutton(transcode_frame, text="Custom", variable=self.var_custom, command=self.toggle_custom_entry)
        custom_check.grid(row=4, column=0, sticky="w")
        self.custom_entry = ttk.Entry(transcode_frame, state='disabled')
        self.custom_entry.grid(row=4, column=1, padx=5, pady=2)
        
        # DIT Folder Options
        dit_options_frame = ttk.LabelFrame(self, text="DIT Folder Options", padding=10)
        dit_options_frame.grid(row=7, column=0, columnspan=2, padx=10, pady=10, sticky="ew")
        self.var_dit_luts = tk.BooleanVar(value=True)
        self.var_dit_framing = tk.BooleanVar(value=True)
        self.var_dit_logs = tk.BooleanVar(value=True)
        self.var_dit_resolve = tk.BooleanVar(value=True)
        self.var_dit_stills = tk.BooleanVar(value=True)
        ttk.Checkbutton(dit_options_frame, text="LUTS", variable=self.var_dit_luts).grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(dit_options_frame, text="FRAMING_CHARTS", variable=self.var_dit_framing).grid(row=0, column=1, sticky="w")
        ttk.Checkbutton(dit_options_frame, text="LOGS", variable=self.var_dit_logs).grid(row=0, column=2, sticky="w")
        ttk.Checkbutton(dit_options_frame, text="RESOLVE_PROJECT", variable=self.var_dit_resolve).grid(row=1, column=0, sticky="w")
        ttk.Checkbutton(dit_options_frame, text="STILLS", variable=self.var_dit_stills).grid(row=1, column=1, sticky="w")
        
        # Custom DIT option
        self.var_custom_dit = tk.BooleanVar(value=False)
        custom_dit_check = ttk.Checkbutton(dit_options_frame, text="Custom", variable=self.var_custom_dit, command=self.toggle_custom_dit_entry)
        custom_dit_check.grid(row=1, column=2, sticky="w")
        self.custom_dit_entry = ttk.Entry(dit_options_frame, state='disabled')
        self.custom_dit_entry.grid(row=1, column=3, padx=5, pady=2)
        
        # MOS option for Audio folder
        self.var_mos = tk.BooleanVar(value=False)
        ttk.Checkbutton(self, text="MOS (change AUDIO folder to MOS)", variable=self.var_mos).grid(row=8, column=0, columnspan=2, pady=10)
        
        # Button to create project folders
        self.create_project_button = ttk.Button(self, text="Create Project", style="DIT.TButton", command=self.create_project)
        self.create_project_button.grid(row=9, column=0, columnspan=2, pady=10)
    
    def update_preview(self, event=None):
        job = self.job_entry.get().strip()
        client = self.client_entry.get().strip()
        project = self.project_entry.get().strip()
        current_date = datetime.now().strftime("%Y%m%d")
        self.preview_var.set(f"{job}_{client}_{project}_{current_date}")
    
    def select_directory(self):
        selected_dir = filedialog.askdirectory(title="Select Output Directory")
        if selected_dir:
            self.output_directory = selected_dir
            self.directory_label.config(text=f"Output Directory: {self.output_directory}")
    
    def toggle_custom_entry(self):
        if self.var_custom.get():
            self.custom_entry.config(state='normal')
        else:
            self.custom_entry.delete(0, tk.END)
            self.custom_entry.config(state='disabled')
    
    def toggle_custom_dit_entry(self):
        if self.var_custom_dit.get():
            self.custom_dit_entry.config(state='normal')
        else:
            self.custom_dit_entry.delete(0, tk.END)
            self.custom_dit_entry.config(state='disabled')
    
    def create_project(self):
        job = self.job_entry.get().strip()
        client = self.client_entry.get().strip()
        project = self.project_entry.get().strip()
        if not job or not client or not project:
            messagebox.showwarning("Missing Information", "Please fill in all fields.")
            return
        if not self.output_directory:
            messagebox.showwarning("No Output Directory", "Please select an output directory.")
            return
        current_date = datetime.now().strftime("%Y%m%d")
        main_folder_name = f"{job}_{client}_{project}_{current_date}"
        main_folder_path = os.path.join(self.output_directory, main_folder_name)
        try:
            os.makedirs(main_folder_path, exist_ok=True)
            # Static subdirectories
            audio_folder_name = f"{'MOS' if self.var_mos.get() else 'AUDIO'}_{current_date}"
            static_dirs = [
                f"ORIGINAL_CAMERA_NEGATIVE_ONLINE_{current_date}",
                audio_folder_name
            ]
            for folder in static_dirs:
                os.makedirs(os.path.join(main_folder_path, folder), exist_ok=True)
            # Transcode directories
            transcode_dirs = []
            if self.var_dnxdh.get():
                transcode_dirs.append(f"AVID_DNxHD_36_MXF_1080P_OFFLINE_{current_date}")
            if self.var_dnxhr.get():
                transcode_dirs.append(f"AVID_DNxHR_LB_MXF_1080P_OFFLINE_{current_date}")
            if self.var_prores_proxy.get():
                transcode_dirs.append(f"PRORES_422_PROXY_1080P_OFFLINE_{current_date}")
            if self.var_prores_lt.get():
                transcode_dirs.append(f"PRORES_422_LT_1080P_OFFLINE_{current_date}")
            if self.var_custom.get():
                custom_text = self.custom_entry.get().strip()
                if custom_text:
                    transcode_dirs.append(f"{custom_text}_{current_date}")
            for folder in transcode_dirs:
                os.makedirs(os.path.join(main_folder_path, folder), exist_ok=True)
            # DIT folder and options
            dit_folder = f"DIT_{current_date}"
            dit_path = os.path.join(main_folder_path, dit_folder)
            os.makedirs(dit_path, exist_ok=True)
            if self.var_dit_luts.get():
                os.makedirs(os.path.join(dit_path, "LUTS"), exist_ok=True)
            if self.var_dit_framing.get():
                os.makedirs(os.path.join(dit_path, "FRAMING_CHARTS"), exist_ok=True)
            if self.var_dit_logs.get():
                os.makedirs(os.path.join(dit_path, "LOGS"), exist_ok=True)
            if self.var_dit_resolve.get():
                os.makedirs(os.path.join(dit_path, "RESOLVE_PROJECT"), exist_ok=True)
            if self.var_dit_stills.get():
                os.makedirs(os.path.join(dit_path, "STILLS"), exist_ok=True)
            if self.var_custom_dit.get():
                custom_dit_text = self.custom_dit_entry.get().strip()
                if custom_dit_text:
                    os.makedirs(os.path.join(dit_path, f"{custom_dit_text}_{current_date}"), exist_ok=True)
            messagebox.showinfo("Success", f"Project directories created at:\n{main_folder_path}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

# ------------------------- Sync Tool Section -------------------------
class SyncFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        UIStyle.configure_styles()
        self.current_sync_process = None
        self.cancel_flag = False
        self.log_directory = None
        
        sync1_frame = ttk.LabelFrame(self, text="Sync Option 1", padding=10)
        sync1_frame.pack(fill="x", padx=10, pady=5)
        ttk.Label(sync1_frame, text="Source Directory:", style="DIT.TLabel").grid(row=0, column=0, sticky="e", padx=5, pady=5)
        self.sync1_source_entry = ttk.Entry(sync1_frame, width=50)
        self.sync1_source_entry.grid(row=0, column=1, padx=5, pady=5)
        ttk.Button(sync1_frame, text="Select Source", style="DIT.TButton",
                   command=lambda: self.select_directory(self.sync1_source_entry)).grid(row=0, column=2, padx=5, pady=5)
        
        self.sync1_dest_entries = []
        for i in range(4):
            ttk.Label(sync1_frame, text=f"Destination Directory {i+1}:", style="DIT.TLabel").grid(row=i+1, column=0, sticky="e", padx=5, pady=5)
            entry = ttk.Entry(sync1_frame, width=50)
            entry.grid(row=i+1, column=1, padx=5, pady=5)
            self.sync1_dest_entries.append(entry)
            ttk.Button(sync1_frame, text="Select Destination", style="DIT.TButton",
                       command=lambda e=entry: self.select_directory(e)).grid(row=i+1, column=2, padx=5, pady=5)
        
        ttk.Button(sync1_frame, text="Sync", style="DIT.TButton", command=self.run_sync1).grid(row=5, column=1, pady=10)
        ttk.Button(sync1_frame, text="Cancel Sync", style="DIT.TButton", command=self.cancel_sync).grid(row=5, column=2, pady=10)
        
        sync2_frame = ttk.LabelFrame(self, text="Sync Option 2", padding=10)
        sync2_frame.pack(fill="x", padx=10, pady=5)
        ttk.Label(sync2_frame, text="Source Directory:", style="DIT.TLabel").grid(row=0, column=0, sticky="e", padx=5, pady=5)
        self.sync2_source_entry = ttk.Entry(sync2_frame, width=50)
        self.sync2_source_entry.grid(row=0, column=1, padx=5, pady=5)
        ttk.Button(sync2_frame, text="Select Source", style="DIT.TButton",
                   command=lambda: self.select_directory(self.sync2_source_entry)).grid(row=0, column=2, padx=5, pady=5)
        
        self.sync2_dest_entries = []
        for i in range(4):
            ttk.Label(sync2_frame, text=f"Destination Directory {i+1}:", style="DIT.TLabel").grid(row=i+1, column=0, sticky="e", padx=5, pady=5)
            entry = ttk.Entry(sync2_frame, width=50)
            entry.grid(row=i+1, column=1, padx=5, pady=5)
            self.sync2_dest_entries.append(entry)
            ttk.Button(sync2_frame, text="Select Destination", style="DIT.TButton",
                       command=lambda e=entry: self.select_directory(e)).grid(row=i+1, column=2, padx=5, pady=5)
        
        ttk.Button(sync2_frame, text="Sync", style="DIT.TButton", command=self.run_sync2).grid(row=5, column=1, pady=10)
        ttk.Button(sync2_frame, text="Cancel Sync", style="DIT.TButton", command=self.cancel_sync).grid(row=5, column=2, pady=10)
        
        ttk.Button(self, text="Clear Directories", style="DIT.TButton", command=self.clear_directories).pack(pady=5)
        
        checkbox_frame = ttk.Frame(self)
        checkbox_frame.pack(padx=10, pady=5, anchor="w")
        self.global_logging_enabled = tk.BooleanVar(value=True)
        self.logging_dest_enabled = tk.BooleanVar(value=False)
        ttk.Checkbutton(checkbox_frame, text="Enable Logging", variable=self.global_logging_enabled).pack(side="left", padx=5)
        ttk.Checkbutton(checkbox_frame, text="Enable Logging Destination", variable=self.logging_dest_enabled).pack(side="left", padx=5)
        
        ttk.Button(self, text="Log Directory", style="DIT.TButton", command=self.choose_log_directory).pack(pady=5, anchor="w", padx=10)
        
        self.output_window = tk.Text(self, height=15, width=100)
        self.output_window.pack(padx=10, pady=10)
    
    def select_directory(self, entry):
        directory = filedialog.askdirectory(title="Select Directory")
        if directory:
            entry.delete(0, tk.END)
            entry.insert(0, directory)
    
    def choose_log_directory(self):
        directory = filedialog.askdirectory(title="Select Log Directory")
        if directory:
            self.log_directory = directory
            messagebox.showinfo("Log Directory", f"Log directory set to: {directory}")
    
    def run_sync(self, source, dest_list):
        if not source:
            messagebox.showerror("Error", "Source directory must be selected.")
            return
        self.cancel_flag = False
        global_log_file = None
        global_log_filename = None
        if self.global_logging_enabled.get():
            try:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                if self.log_directory:
                    global_log_filename = os.path.join(self.log_directory, f"rsync_log_{timestamp}.txt")
                else:
                    global_log_filename = f"rsync_log_{timestamp}.txt"
                global_log_file = open(global_log_filename, "w")
                global_log_file.write(f"--- Global Sync Started for source: {source} ---\n")
            except Exception as e:
                messagebox.showerror("Global Logging Error", f"Failed to open global log file: {e}")
                global_log_file = None
                global_log_filename = None
        for dest in dest_list:
            if self.cancel_flag:
                self.output_window.insert(tk.END, "Sync cancelled by user.\n")
                break
            if not dest.strip():
                continue
            self.output_window.insert(tk.END, f"\nStarting sync: {source} -> {dest}\n")
            dest_log_file = None
            if self.logging_dest_enabled.get():
                log_path = os.path.join(dest, "rsync_log.txt")
                try:
                    dest_log_file = open(log_path, "a")
                    dest_log_file.write(f"--- Sync started: {source} -> {dest} ---\n")
                except Exception as e:
                    messagebox.showerror("Destination Logging Error", f"Failed to open log file at {log_path}: {e}")
                    dest_log_file = None
            command = ["rsync", "-av", "--progress", source, dest]
            try:
                self.current_sync_process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                while True:
                    if self.cancel_flag:
                        self.current_sync_process.terminate()
                        self.output_window.insert(tk.END, "Cancelling current sync...\n")
                        break
                    line = self.current_sync_process.stdout.readline()
                    if not line and self.current_sync_process.poll() is not None:
                        break
                    if line:
                        self.output_window.insert(tk.END, line)
                        self.output_window.see(tk.END)
                        self.output_window.update()
                        if global_log_file:
                            global_log_file.write(line)
                            global_log_file.flush()
                        if dest_log_file:
                            dest_log_file.write(line)
                            dest_log_file.flush()
                if dest_log_file:
                    dest_log_file.write(f"--- Sync finished for {dest} ---\n\n")
                    dest_log_file.close()
                if global_log_file:
                    global_log_file.write(f"--- Sync finished for {dest} ---\n")
                    global_log_file.flush()
                if self.cancel_flag:
                    break
            except Exception as e:
                messagebox.showerror("Execution Error", f"Failed to run sync on {dest}: {e}")
        if global_log_file:
            global_log_file.write(f"--- Global Sync Finished for source: {source} ---\n\n")
            global_log_file.close()
        if self.cancel_flag and global_log_filename is not None:
            try:
                os.remove(global_log_filename)
                self.output_window.insert(tk.END, "Partial global log cleared.\n")
            except Exception as e:
                self.output_window.insert(tk.END, f"Error clearing partial global log: {e}\n")
        self.current_sync_process = None
    
    def run_sync1(self):
        source = self.sync1_source_entry.get().strip()
        dest_list = [entry.get().strip() for entry in self.sync1_dest_entries]
        threading.Thread(target=self.run_sync, args=(source, dest_list), daemon=True).start()
    
    def run_sync2(self):
        source = self.sync2_source_entry.get().strip()
        dest_list = [entry.get().strip() for entry in self.sync2_dest_entries]
        threading.Thread(target=self.run_sync, args=(source, dest_list), daemon=True).start()
    
    def cancel_sync(self):
        self.cancel_flag = True
        if self.current_sync_process is not None:
            try:
                self.current_sync_process.terminate()
            except Exception as e:
                messagebox.showerror("Cancel Error", f"Error cancelling sync: {e}")
    
    def clear_directories(self):
        self.sync1_source_entry.delete(0, tk.END)
        for entry in self.sync1_dest_entries:
            entry.delete(0, tk.END)
        self.sync2_source_entry.delete(0, tk.END)
        for entry in self.sync2_dest_entries:
            entry.delete(0, tk.END)
        self.output_window.delete(1.0, tk.END)

# ------------------------- File Comparator Section -------------------------
def compute_hash(file_path):
    hash_obj = hashlib.sha256()
    try:
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_obj.update(chunk)
    except Exception:
        return None
    return hash_obj.hexdigest()

def scan_drive_attributes(root_path, compare_size, compare_date, compare_hash, skip_hidden=False):
    files_dict = {}
    for dirpath, dirnames, filenames in os.walk(root_path):
        dirnames[:] = [d for d in dirnames if d != '_gsdata_']
        if skip_hidden:
            dirnames[:] = [d for d in dirnames if not d.startswith('.')]
        rel_dir = os.path.relpath(dirpath, root_path)
        if rel_dir != ".":
            key = rel_dir + os.sep
            files_dict[key] = {"type": "directory"}
        for filename in filenames:
            if filename == ".DS_Store":
                continue
            full_path = os.path.join(dirpath, filename)
            rel_path = os.path.relpath(full_path, root_path)
            attr = {"type": "file"}
            if compare_size:
                try:
                    attr['size'] = os.path.getsize(full_path)
                except Exception:
                    attr['size'] = None
            if compare_date:
                try:
                    attr['mod_date'] = os.path.getmtime(full_path)
                except Exception:
                    attr['mod_date'] = None
            if compare_hash:
                attr['hash'] = compute_hash(full_path)
            files_dict[rel_path] = attr
    return files_dict

class FileComparatorFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        UIStyle.configure_styles()
        self.drive_paths = []
        self.reference_drive = None
        self.log_directory = None
        self.create_widgets()
    
    def create_widgets(self):
        top_frame = ttk.Frame(self)
        top_frame.pack(pady=5)
        self.add_button = ttk.Button(top_frame, text="Add Drive", style="DIT.TButton", command=self.add_drive)
        self.add_button.grid(row=0, column=0, padx=5)
        self.clear_button = ttk.Button(top_frame, text="Clear Drives", style="DIT.TButton", command=self.clear_drives)
        self.clear_button.grid(row=0, column=1, padx=5)
        self.set_ref_button = ttk.Button(top_frame, text="Set as Reference", style="DIT.TButton", command=self.set_reference)
        self.set_ref_button.grid(row=0, column=2, padx=5)
        self.auto_ref_button = ttk.Button(top_frame, text="Auto Reference", style="DIT.TButton", command=self.auto_reference)
        self.auto_ref_button.grid(row=0, column=3, padx=5)
        self.listbox = tk.Listbox(self, selectmode=tk.SINGLE, width=80)
        self.listbox.pack(pady=5)
        self.ref_label = ttk.Label(self, text="Reference Drive: Not Set", style="DIT.TLabel")
        self.ref_label.pack(pady=5)
        options_frame = ttk.LabelFrame(self, text="Comparison Options", padding=10)
        options_frame.pack(pady=5, fill="x", padx=10)
        self.compare_size_var = tk.BooleanVar(value=True)
        self.compare_date_var = tk.BooleanVar(value=False)
        self.compare_hash_var = tk.BooleanVar(value=False)
        self.skip_hidden_var = tk.BooleanVar(value=True)
        self.cb_size = ttk.Checkbutton(options_frame, text="Compare Size", variable=self.compare_size_var)
        self.cb_size.grid(row=0, column=0, padx=5, pady=2, sticky="w")
        self.cb_date = ttk.Checkbutton(options_frame, text="Compare Modification Date", variable=self.compare_date_var)
        self.cb_date.grid(row=0, column=1, padx=5, pady=2, sticky="w")
        self.cb_hash = ttk.Checkbutton(options_frame, text="Compare File Hash", variable=self.compare_hash_var)
        self.cb_hash.grid(row=0, column=2, padx=5, pady=2, sticky="w")
        self.cb_hidden = ttk.Checkbutton(options_frame, text="Skip Hidden Directories", variable=self.skip_hidden_var)
        self.cb_hidden.grid(row=1, column=0, padx=5, pady=2, sticky="w")
        self.fc_global_logging_enabled = tk.BooleanVar(value=False)
        self.fc_dest_logging_enabled = tk.BooleanVar(value=False)
        ttk.Checkbutton(options_frame, text="Enable Logging", variable=self.fc_global_logging_enabled).grid(row=2, column=0, padx=5, pady=2, sticky="w")
        ttk.Checkbutton(options_frame, text="Enable Logging Destination", variable=self.fc_dest_logging_enabled).grid(row=2, column=1, padx=5, pady=2, sticky="w")
        ttk.Button(options_frame, text="Log Directory", style="DIT.TButton", command=self.choose_log_directory).grid(row=3, column=0, padx=5, pady=5, sticky="w")
        
        self.progress_bar = ttk.Progressbar(self, orient="horizontal", length=500, mode="determinate")
        self.progress_bar.pack(pady=10)
        self.status_label = ttk.Label(self, text="Status: Idle", style="DIT.TLabel")
        self.status_label.pack(pady=5)
        self.compare_button = ttk.Button(self, text="Compare Files", style="DIT.TButton", command=self.compare_files)
        self.compare_button.pack(pady=5)
        self.text_area = scrolledtext.ScrolledText(self, width=80, height=15)
        self.text_area.pack(pady=5)
    
    def choose_log_directory(self):
        directory = filedialog.askdirectory(title="Select Log Directory")
        if directory:
            self.log_directory = directory
            messagebox.showinfo("Log Directory", f"Log directory set to: {directory}")
    
    def add_drive(self):
        drive = filedialog.askdirectory(title="Select External Drive Directory")
        if drive:
            self.drive_paths.append(drive)
            self.listbox.insert(tk.END, drive)
    
    def clear_drives(self):
        self.drive_paths = []
        self.reference_drive = None
        self.listbox.delete(0, tk.END)
        self.ref_label.config(text="Reference Drive: Not Set")
        self.text_area.delete(1.0, tk.END)
        self.progress_bar['value'] = 0
    
    def set_reference(self):
        selection = self.listbox.curselection()
        if selection:
            index = selection[0]
            self.reference_drive = self.drive_paths[index]
            self.ref_label.config(text=f"Reference Drive: {self.reference_drive}")
        else:
            messagebox.showwarning("Selection Error", "Please select a drive from the list to set as reference.")
    
    def auto_reference(self):
        self.clear_drives()
        volumes_root = "/Volumes"
        if not os.path.exists(volumes_root):
            messagebox.showerror("Error", "Volumes directory not found.")
            return
        volumes = [d for d in os.listdir(volumes_root) if os.path.isdir(os.path.join(volumes_root, d))]
        filtered_volumes = []
        for vol in volumes:
            if len(vol) >= 3 and vol[-3] == '_' and vol[-2:].isdigit():
                filtered_volumes.append(vol)
        if not filtered_volumes:
            messagebox.showinfo("Auto Reference", "No external volumes with expected naming found.")
            return
        for vol in filtered_volumes:
            full_path = os.path.join(volumes_root, vol)
            self.drive_paths.append(full_path)
            self.listbox.insert(tk.END, full_path)
        reference_drive = None
        for vol in filtered_volumes:
            if vol.endswith("_01"):
                reference_drive = os.path.join(volumes_root, vol)
                break
        if reference_drive:
            self.reference_drive = reference_drive
            self.ref_label.config(text=f"Reference Drive: {reference_drive}")
        else:
            messagebox.showinfo("Auto Reference", "No volume ending with '_01' found to set as reference.")
    
    def compare_files(self):
        if len(self.drive_paths) < 1:
            messagebox.showwarning("No Drives", "Please add at least one drive.")
            return
        self.text_area.delete('1.0', tk.END)
        self.progress_bar['value'] = 0
        self.status_label.config(text="Status: Starting comparison...")
        thread = threading.Thread(target=self.perform_comparison)
        thread.start()
    
    def perform_comparison(self):
        compare_size = self.compare_size_var.get()
        compare_date = self.compare_date_var.get()
        compare_hash = self.compare_hash_var.get()
        skip_hidden = self.skip_hidden_var.get()
        self.update_status("Scanning all drives...")
        drive_files = {}
        for drive in self.drive_paths:
            self.update_status(f"Scanning drive: {drive}")
            drive_files[drive] = scan_drive_attributes(drive, compare_size, compare_date, compare_hash, skip_hidden=skip_hidden)
        all_keys = set()
        for files_dict in drive_files.values():
            all_keys.update(files_dict.keys())
        total_keys = len(all_keys)
        if total_keys == 0:
            self.append_text("No files or directories found on any drive.\n")
            self.update_status("Scan complete. No items found.")
            return
        self.update_status("Comparing items across all drives...")
        discrepancies = {}
        processed = 0
        ref_drive = self.reference_drive if self.reference_drive in drive_files else None
        for key in all_keys:
            processed += 1
            self.update_progress(processed, total_keys)
            ref_attr = drive_files[ref_drive].get(key) if ref_drive else None
            for drive, files_dict in drive_files.items():
                if key not in files_dict:
                    discrepancies.setdefault(drive, []).append(f"Missing item: {key}")
                else:
                    comp_attr = files_dict[key]
                    if ref_attr:
                        if ref_attr.get("type") != comp_attr.get("type"):
                            discrepancies.setdefault(drive, []).append(
                                f"Type mismatch for {key} (Ref: {ref_attr.get('type')}, {drive}: {comp_attr.get('type')})"
                            )
                        elif ref_attr.get("type") == "file":
                            messages = []
                            if compare_size and ref_attr.get('size') != comp_attr.get('size'):
                                messages.append(f"Size mismatch for {key} (Ref: {ref_attr.get('size')}, {drive}: {comp_attr.get('size')})")
                            if compare_date and ref_attr.get('mod_date') != comp_attr.get('mod_date'):
                                messages.append(f"Modification date mismatch for {key}")
                            if compare_hash and ref_attr.get('hash') != comp_attr.get('hash'):
                                messages.append(f"Hash mismatch for {key}")
                            if messages:
                                discrepancies.setdefault(drive, []).extend(messages)
        if not discrepancies:
            self.append_text("All drives have the same items and attributes.\n")
            self.update_status("Comparison complete. No discrepancies found.")
            messagebox.showinfo("Comparison Result", "All drives match across all items.")
        else:
            result_text = ""
            for drive, messages in discrepancies.items():
                result_text += f"Discrepancies for drive: {drive}\n"
                for msg in messages:
                    result_text += "  " + msg + "\n"
                result_text += "\n"
            self.append_text(result_text)
            log_files = {}
            if self.fc_global_logging_enabled.get():
                log_files["global"] = self.write_global_log(discrepancies)
            if self.fc_dest_logging_enabled.get():
                log_files["destination"] = self.write_dest_logs(discrepancies)
            self.update_status("Comparison complete with discrepancies.")
            messagebox.showwarning("Differences Found", f"Discrepancies found. Logs: {log_files}")
    
    def write_global_log(self, discrepancies):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        if self.log_directory:
            log_filename = os.path.join(self.log_directory, f"file_comparison_log_{timestamp}.txt")
        else:
            log_filename = f"file_comparison_log_{timestamp}.txt"
        with open(log_filename, "w") as log_file:
            for drive, messages in discrepancies.items():
                log_file.write(f"Discrepancies for drive: {drive}\n")
                for msg in messages:
                    log_file.write("  " + msg + "\n")
                log_file.write("\n")
        return log_filename
    
    def write_dest_logs(self, discrepancies):
        dest_log_files = {}
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        for drive, messages in discrepancies.items():
            if messages:
                dest_log_path = os.path.join(drive, f"file_comparison_log_{timestamp}.txt")
                with open(dest_log_path, "w") as log_file:
                    log_file.write(f"Discrepancies for drive: {drive}\n")
                    for msg in messages:
                        log_file.write("  " + msg + "\n")
                    log_file.write("\n")
                dest_log_files[drive] = dest_log_path
        return dest_log_files
    
    def update_status(self, message):
        self.status_label.after(0, lambda: self.status_label.config(text=f"Status: {message}"))
    
    def append_text(self, text):
        self.text_area.after(0, lambda: self.text_area.insert(tk.END, text))
    
    def update_progress(self, value, maximum):
        self.progress_bar.after(0, lambda: self.progress_bar.config(value=value, maximum=maximum))

# ------------------------- Render Check Section -------------------------
class RenderCheckFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        UIStyle.configure_styles()
        self.init_paths()
        self.create_gui()
    
    def init_paths(self):
        self.originals_path = tk.StringVar()
        self.transcode_paths = [tk.StringVar() for _ in range(4)]
        self.enable_logging = tk.BooleanVar(value=False)
        self.log_path = os.path.expanduser("~/Desktop/RenderCheckLogs")
        self.render_check_path = os.path.expanduser("~/Library/RenderCheck")
        os.makedirs(self.render_check_path, exist_ok=True)
        os.makedirs(self.log_path, exist_ok=True)
    
    def create_gui(self):
        main_frame = ttk.Frame(self, padding=10)
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        main_frame.columnconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        
        ttk.Label(main_frame, text="Camera Originals", style="Header.TLabel").grid(row=0, column=0, sticky=tk.W, pady=(0,10))
        originals_frame = ttk.Frame(main_frame)
        originals_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0,20))
        ttk.Entry(originals_frame, textvariable=self.originals_path, width=60).grid(row=0, column=0, padx=(0,5))
        ttk.Button(originals_frame, text="Browse", style="DIT.TButton",
                   command=lambda: self.browse_folder(self.originals_path)).grid(row=0, column=1)
        
        ttk.Label(main_frame, text="Transcodes", style="Header.TLabel").grid(row=2, column=0, sticky=tk.W, pady=(0,10))
        for i in range(4):
            transcode_frame = ttk.Frame(main_frame)
            transcode_frame.grid(row=3+i, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0,10))
            ttk.Entry(transcode_frame, textvariable=self.transcode_paths[i], width=60).grid(row=0, column=0, padx=(0,5))
            ttk.Button(transcode_frame, text="Browse", style="DIT.TButton",
                       command=lambda x=i: self.browse_folder(self.transcode_paths[x])).grid(row=0, column=1)
        
        ttk.Checkbutton(main_frame, text="Enable logging", variable=self.enable_logging).grid(row=7, column=0, sticky=tk.W, pady=(20,0))
        self.log_path_label = ttk.Label(main_frame, text=f"Logs will be saved to: {self.log_path}", style="DIT.TLabel")
        self.log_path_label.grid(row=8, column=0, columnspan=2, sticky=tk.W)
        ttk.Button(main_frame, text="Log Directory", style="DIT.TButton", command=self.choose_log_directory).grid(row=9, column=0, pady=5, sticky="w")
        
        ttk.Button(main_frame, text="Check Renders", style="DIT.TButton",
                   command=self.run_comparison).grid(row=10, column=0, columnspan=2, pady=(20,0))
        self.results_text = tk.Text(main_frame, height=10, width=70)
        self.results_text.grid(row=11, column=0, columnspan=2, pady=(20,0))
    
    def browse_folder(self, path_var):
        folder_path = filedialog.askdirectory()
        if folder_path:
            path_var.set(folder_path)
    
    def process_camera_originals(self, folder_path):
        file_list = []
        for root, _, files in os.walk(folder_path):
            for file in files:
                if any(file.lower().endswith(ext) for ext in ('.mov', '.mxf', '.rdc', '.cine', '.mp4', '.ari', '.arx', '.dng')):
                    file_list.append(os.path.join(root, file))
        processed_names = set()
        for file_path in file_list:
            filename = os.path.basename(file_path)
            name = re.sub(r'\.(MXF|mxf|mov|MOV|RDC|cine|mp4|MP4|ari|arx|dng|DNG)$', '', filename)
            if any(x in name for x in ('Cine', 'Blackmagic', '_201')):
                processed_name = name
            else:
                processed_name = name[:10]
            processed_name = re.sub(r'_[0-9A-Z]$', '', processed_name)
            processed_name = re.sub(r'_$', '', processed_name)
            processed_names.add(processed_name)
        return processed_names
    
    def process_transcodes(self, folder_path):
        file_list = []
        for root, _, files in os.walk(folder_path):
            for file in files:
                if file.lower().endswith(('.mov', '.mxf')):
                    if not re.search(r'_A\d+\.mxf$', file):
                        file_list.append(os.path.join(root, file))
        processed_names = set()
        for file_path in file_list:
            filename = os.path.basename(file_path)
            name = re.sub(r'\.(mxf|mov)$', '', filename)
            if any(x in name for x in ('Cine', 'Blackmagic', '_201')):
                processed_name = name
            else:
                processed_name = name[:10]
            processed_name = re.sub(r'_[0-9A-Z]$', '', processed_name)
            processed_name = re.sub(r'_$', '', processed_name)
            processed_names.add(processed_name)
        return processed_names
    
    def write_to_log(self, message):
        if self.enable_logging.get():
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            log_file = os.path.join(self.log_path, f"rendercheck_log_{timestamp}.txt")
            with open(log_file, 'a') as f:
                f.write(f"{message}\n")
    
    def choose_log_directory(self):
        directory = filedialog.askdirectory(title="Select Log Directory")
        if directory:
            self.log_path = directory
            self.log_path_label.config(text=f"Logs will be saved to: {self.log_path}")
            messagebox.showinfo("Log Directory", f"Log directory set to: {directory}")
    
    def run_comparison(self):
        self.results_text.delete(1.0, tk.END)
        if not self.originals_path.get():
            self.results_text.insert(tk.END, "Please select Camera Originals directory\n")
            return
        originals = self.process_camera_originals(self.originals_path.get())
        self.write_to_log(f"\nCamera Originals Directory: {self.originals_path.get()}")
        self.write_to_log(f"Found {len(originals)} original files")
        for i, transcode_path in enumerate(self.transcode_paths):
            if not transcode_path.get():
                continue
            transcodes = self.process_transcodes(transcode_path.get())
            missing_in_transcodes = originals - transcodes
            extra_in_transcodes = transcodes - originals
            result = f"\nResults for Transcode Directory {i+1}:\n"
            result += f"Directory: {transcode_path.get()}\n"
            if not missing_in_transcodes and not extra_in_transcodes:
                result += "Success! All files match.\n"
            else:
                if missing_in_transcodes:
                    result += "\nMissing in transcodes:\n" + "\n".join(sorted(missing_in_transcodes))
                if extra_in_transcodes:
                    result += "\nExtra files in transcodes:\n" + "\n".join(sorted(extra_in_transcodes))
            self.results_text.insert(tk.END, result)
            self.write_to_log(result)
    
    def update_status(self, message):
        self.status_label.after(0, lambda: self.status_label.config(text=f"Status: {message}"))
    
    def append_text(self, text):
        self.results_text.after(0, lambda: self.results_text.insert(tk.END, text))
    
    def update_progress(self, value, maximum):
        self.progress_bar.after(0, lambda: self.progress_bar.config(value=value, maximum=maximum))

# ------------------------- Trash .drx Files Section -------------------------
class TrashDrxFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        UIStyle.configure_styles()
        self.selected_directory = ""
        self.create_widgets()
    
    def create_widgets(self):
        self.load_btn = ttk.Button(self, text="Load Directory", style="DIT.TButton", command=self.load_directory)
        self.load_btn.pack(pady=10)
        self.dir_label = ttk.Label(self, text="No directory selected", style="DIT.TLabel")
        self.dir_label.pack(pady=5)
        self.trash_btn = ttk.Button(self, text="Trash .drx", style="DIT.TButton", command=self.trash_drx)
        self.trash_btn.pack(pady=10)
        self.output_text = tk.Text(self, height=15, width=100)
        self.output_text.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
    
    def load_directory(self):
        directory = filedialog.askdirectory(title="Select Directory")
        if directory:
            self.selected_directory = directory
            self.dir_label.config(text=f"Selected Directory: {directory}")
            self.log_output(f"Loaded directory: {directory}")
    
    def trash_drx(self):
        if not self.selected_directory:
            messagebox.showerror("Error", "No directory selected. Please load a directory first.")
            return
        self.log_output("Starting to trash .drx files...\n")
        move_drx_files(self.selected_directory, output_callback=self.log_output)
        self.log_output("\nOperation completed.")
    
    def log_output(self, message):
        self.output_text.insert(tk.END, message + "\n")
        self.output_text.see(tk.END)

def move_drx_files(target_directory, output_callback=None):
    trash_dir = os.path.expanduser("~/.Trash")
    if not os.path.isdir(trash_dir):
        if output_callback:
            output_callback(f"Trash directory not found: {trash_dir}")
        return
    files_moved = 0
    for root_dir, dirs, files in os.walk(target_directory):
        for file in files:
            if file.endswith(".drx"):
                src = os.path.join(root_dir, file)
                dest = os.path.join(trash_dir, file)
                base, ext = os.path.splitext(file)
                counter = 1
                while os.path.exists(dest):
                    dest = os.path.join(trash_dir, f"{base}_{counter}{ext}")
                    counter += 1
                if output_callback:
                    output_callback(f"Moving: {src} -> {dest}")
                shutil.move(src, dest)
                files_moved += 1
    if output_callback:
        output_callback(f"Total .drx files moved: {files_moved}")

# ------------------------- Main Application -------------------------
def main():
    root = tk.Tk()
    root.title("DIT Tools")
    UIStyle.configure_styles()
    notebook = ttk.Notebook(root)
    
    project_frame = ProjectFrame(notebook)
    notebook.add(project_frame, text="Project")
    
    sync_frame = SyncFrame(notebook)
    notebook.add(sync_frame, text="Sync")
    
    comparator_frame = FileComparatorFrame(notebook)
    notebook.add(comparator_frame, text="File Comparator")
    
    render_frame = RenderCheckFrame(notebook)
    notebook.add(render_frame, text="Render Check")
    
    trash_frame = TrashDrxFrame(notebook)
    notebook.add(trash_frame, text="Trash .drx Files")
    
    notebook.pack(fill="both", expand=True)
    root.mainloop()

if __name__ == "__main__":
    main()